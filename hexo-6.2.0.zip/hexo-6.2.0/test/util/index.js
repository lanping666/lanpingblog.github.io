'use strict';

exports.stream = require('./stream');
