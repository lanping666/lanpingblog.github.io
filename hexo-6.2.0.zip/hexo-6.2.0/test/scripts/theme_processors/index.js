'use strict';

describe('Theme processors', () => {
  require('./config');
  require('./i18n');
  require('./source');
  require('./view');
});
