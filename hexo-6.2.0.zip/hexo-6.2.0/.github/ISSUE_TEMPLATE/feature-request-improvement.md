---
name: Feature request / Improvement
about: I have a feature request, suggestion, improvement etc...
title: ''
labels: ''
assignees: ''

---

## Check List

Please check followings before submitting a new feature request.

- [ ] I have already read [Docs page](https://hexo.io/docs/)
- [ ] I have already searched existing issues

## Feature Request

<!-- Feature Request description -->

## Others

<!-- If you have other information. Please write here. -->
